<template>
  <div class="home">
    <router-view></router-view>
  </div>
</template>

<script>
// @ is an alias to /src
//import UserLogin from "@/components/user/UserLogin.vue";

export default {
  name: "HomeView",
  components: {}
};
</script>
