<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "AppBoard"
};
</script>

<style scoped></style>
